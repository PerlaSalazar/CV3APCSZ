class Producto {
  String producto;
  // String? url;
  String? foto;

  // String sfoto = foto ?? 'default';
  int? stock;

  Producto({required this.producto, this.foto, this.stock});
}
